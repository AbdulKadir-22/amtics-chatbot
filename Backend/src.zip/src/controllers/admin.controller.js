const ingestionService = require('../services/ingestion.service');
const Document = require('../models/Document');
const asyncHandler = require('../utils/asyncHandler');

const uploadDocument = asyncHandler(async (req, res) => {
    if (!req.file) {
        return res.status(400).json({ success: false, message: 'No file uploaded' });
    }

    const result = await ingestionService.ingestFile(req.file);

    res.status(201).json({
        success: true,
        message: `Document ingested successfully into ${result.count} chunks`,
    });
});

const getDocuments = asyncHandler(async (req, res) => {
    const documents = await Document.distinct('filename');
    res.status(200).json({ success: true, data: documents });
});

const deleteDocument = asyncHandler(async (req, res) => {
    const { filename } = req.params;
    await Document.deleteMany({ filename });
    res.status(200).json({ success: true, message: `Document ${filename} deleted` });
});

module.exports = {
    uploadDocument,
    getDocuments,
    deleteDocument,
};

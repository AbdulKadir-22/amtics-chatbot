const Chat = require('../models/Chat');
const Message = require('../models/Message');
const aiService = require('../services/ai.service');
const ragService = require('../services/rag.service');
const cacheService = require('../services/cache.service');
const asyncHandler = require('../utils/asyncHandler');

/**
 * Controller for chat interactions
 */
const handleChat = asyncHandler(async (req, res) => {
    const { message, chatId } = req.body;

    if (!message) {
        return res.status(400).json({ success: false, message: 'Message is required' });
    }

    // 1. Check Cache
    const cachedResponse = cacheService.get(message.toLowerCase());
    if (cachedResponse) {
        return res.status(200).json({ success: true, response: cachedResponse, cached: true });
    }

    // 2. Identify or Create Chat
    let chat;
    if (chatId) {
        chat = await Chat.findById(chatId);
    }
    if (!chat) {
        chat = await Chat.create({ title: message.substring(0, 30) + '...' });
    }

    // 3. Save User Message
    await Message.create({ chatId: chat._id, role: 'user', content: message });

    // 4. Retrieve Context (RAG)
    const context = await ragService.getRelevantContext(message);

    // 5. Get Previous History (last 5 messages for performance)
    const history = await Message.find({ chatId: chat._id })
        .sort({ createdAt: -1 })
        .limit(5);

    const formattedHistory = history.reverse().map(m => ({ role: m.role, content: m.content }));

    // 6. Build Prompt with Context
    const systemPrompt = `You are a helpful College Assistant. Use the following context to answer the student's question accurately. If you don't know the answer based on the context, say you don't know based on available info.
  
  Context:
  ${context}`;

    const messages = [
        { role: 'system', content: systemPrompt },
        ...formattedHistory
    ];

    // 7. Get AI Response
    const aiResponse = await aiService.getChatCompletion(messages);

    // 8. Save AI Message
    await Message.create({ chatId: chat._id, role: 'assistant', content: aiResponse });

    // 9. Cache Response
    cacheService.set(message.toLowerCase(), aiResponse);

    res.status(200).json({
        success: true,
        chatId: chat._id,
        response: aiResponse,
    });
});

const getChatHistory = asyncHandler(async (req, res) => {
    const chats = await Chat.find().sort({ createdAt: -1 });
    res.status(200).json({ success: true, data: chats });
});

module.exports = {
    handleChat,
    getChatHistory,
};

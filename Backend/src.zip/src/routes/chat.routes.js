const express = require('express');
const { handleChat, getChatHistory } = require('../controllers/chat.controller');
const apiLimiter = require('../middleware/rateLimit');

const router = express.Router();

router.post('/', apiLimiter, handleChat);
router.get('/history', getChatHistory);

module.exports = router;

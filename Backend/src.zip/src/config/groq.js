const { Groq } = require('groq-sdk');
const dotenv = require('dotenv');

dotenv.config();

if (!process.env.GROQ_API_KEY) {
    console.warn('WARNING: GROQ_API_KEY is not defined in .env file');
}

try {
    const groq = new Groq({
        apiKey: process.env.GROQ_API_KEY,
    });
    console.log("API key us connected");
} catch (error) {
    console.log("API key is not connected");
}

module.exports = groq;
